package Game;

import java.io.*;
import java.net.*;
import java.util.*;

public class Server {

    private static List<Socket> clients = new ArrayList<>();
    private static List<String> names = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(8000);
        System.out.println("Server started. Waiting for clients...");

        while (true) {
            Socket socket = server.accept();
            clients.add(socket);
            new Thread(new ClientHandler(socket)).start();
        }
    }

    private static void broadcast(String message, String sender) {
        for (Socket socket : clients) {
            try {
                PrintWriter writer = new PrintWriter(socket.getOutputStream());
                writer.println(sender + ": " + message);
                writer.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket socket;
        private String name;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                name = reader.readLine();
                names.add(name);

                broadcast(name + " has joined the chat.", "Server");

                while (true) {
                    String message = reader.readLine();
                    if (message.equals("exit")) {
                        break;
                    }
                    broadcast(message, name);
                }

                broadcast(name + " has left the chat.", "Server");
                names.remove(name);
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}