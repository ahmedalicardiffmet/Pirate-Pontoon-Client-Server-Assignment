package Game;

import java.io.*;
import java.net.*;
import java.util.*;

public class Client {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();

        Socket socket = new Socket("localhost", 8000);
        PrintWriter writer = new PrintWriter(socket.getOutputStream());
        writer.println(name);
        writer.flush();

        new Thread(new Receiver(socket)).start();

        while (true) {
            String message = scanner.nextLine();
            writer.println(message);
            writer.flush();
        }
    }

    private static class Receiver implements Runnable {
        private Socket socket;

        public Receiver(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                while (true) {
                    String message = reader.readLine();
                    System.out.println(message);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
