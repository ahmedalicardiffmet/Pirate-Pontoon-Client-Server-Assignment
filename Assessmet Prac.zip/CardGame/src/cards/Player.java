package cards;

public class Player {
    private String name;
    private int value;

    public Player(String name) {
        this.name = name;
        this.value = 0;
    }

    public void addCard(Card c) {
        if (c.getValue() == 1) {
            if (value + 11 > 21) {
                value += 1;
            } else {
                value += 11;
            }
        } else if (c.getValue() > 10) {
            value += 10;
        } else {
            value += c.getValue();
        }
    }

    public int getValue() {
        return value;
    }

    public String getName() {
        return name;
    }
}


