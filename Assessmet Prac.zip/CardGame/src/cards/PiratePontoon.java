package cards;

import java.util.Scanner;

public class PiratePontoon {
    public static void main(String[] args) {
        Deck deck = new Deck();
        Player player = new Player("Player");
        Player dealer = new Player("Dealer");
        
        // Deal initial cards
        player.addCard(deck.drawCard());
        dealer.addCard(deck.drawCard());
        player.addCard(deck.drawCard());
        dealer.addCard(deck.drawCard());

        Scanner input = new Scanner(System.in);

        // Player's turn
        System.out.println("Your hand value: " + player.getValue());
        while (player.getValue() < 21) {
            System.out.println("Do you want to hit or stand? (Enter 'hit' or 'stand')");
            String choice = input.nextLine();
            if (choice.equalsIgnoreCase("hit")) {
                player.addCard(deck.drawCard());
                System.out.println("Your hand value: " + player.getValue());
            } else if (choice.equalsIgnoreCase("stand")) {
                break;
            }
        }

        // Check if player has bust
        if (player.getValue() > 21) {
            System.out.println("You bust! You lose.");
            return;
        }

    }
    
}