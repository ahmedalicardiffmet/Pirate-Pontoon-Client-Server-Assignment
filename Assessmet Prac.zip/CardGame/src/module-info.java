/**
 * 
 */
/**
 * @author User
 *
 */
module CardGame {
}